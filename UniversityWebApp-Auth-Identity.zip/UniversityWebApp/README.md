
Add-Migration PeixeEspada -context SchoolContext

Add-Migration Tilapia -context ApplicationDbContext

Update-Database -Context ApplicationDbContext

Update-Database -Context SchoolContext
