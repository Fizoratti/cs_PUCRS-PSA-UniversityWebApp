
Menu Compila��o>Recompilar Solu��o

Apagar pasta 'Migrations' no projeto 'Persistencia'

Abrir o Console do Gerenciador de Pacotes NuGet e selecionar no Projeto padr�o 'Persistencia'

Add-Migration PeixeEspada -context SchoolContext

Update-Database -Context SchoolContext
