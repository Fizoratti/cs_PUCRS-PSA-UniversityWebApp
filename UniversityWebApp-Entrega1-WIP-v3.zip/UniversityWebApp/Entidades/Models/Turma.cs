﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Models
{
    public class Turma
    {
        public int TurmaID { get; set; }
        public string Codcred { get; set; } // 4645B-04
        public string Horario { get; set; }  // 2LM4LM
        public string Numero { get; set; } // 128
    }
}
