﻿update AspNetUsers set Matricula=15111090, Nome='User' where ApplicationUserID=0;

insert into Historico (Nota, Semestre, Matricula) values (7.0, '2021-1', 15111090);
insert into Historico (Nota, Semestre, Matricula) values (7.0, '2020-2', 15111090);
insert into Historico (Nota, Semestre, Matricula) values (7.0, '2020-1', 15111090);
insert into Historico (Nota, Semestre, Matricula) values (7.0, '2021-1', 15111091);


https://we.tl/t-9RBuZK0yYh
