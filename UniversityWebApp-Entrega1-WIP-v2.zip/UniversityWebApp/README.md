
Menu Compila��o>Recompilar Solu��o

Apagar pasta 'Migrations' no projeto 'Persistencia'

Abrir o Console do Gerenciador de Pacotes NuGet

Selecionar 'Persistencia' no Projeto padr�o 

Add-Migration PeixeEspada -context SchoolContext

Update-Database -Context SchoolContext

Rodar a aplica��o

Registrar novo usu�rio

Executar script SQL que adiciona matriculas

Executar script SQL que adiciona uma matr�cula ao usu�rio logado/registrado/autenticado