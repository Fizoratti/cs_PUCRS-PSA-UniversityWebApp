
Add-Migration MyMigration -context SchoolContext

Add-Migration MyMigration -context ApplicationDbContext

Update-Database -Context ApplicationDbContext

Update-Database -Context SchoolContext
